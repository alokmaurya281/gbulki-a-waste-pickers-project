   <?php
require('db.php');

	

$name = mysqli_real_escape_string($con,$_POST['name']);
$email = mysqli_real_escape_string($con,$_POST['email']);
$phone = mysqli_real_escape_string($con,$_POST['phone']);
$password = mysqli_real_escape_string($con,$_POST['password']);
$sql = "INSERT INTO waste_picker(name, email, phone, password) VALUES('$name','$email','$phone','$password')";
		
if(mysqli_query($con, $sql)){

  echo '<script>alert("Registration Successful please login to your account.");window.location.assign("index.php");</script>';
  
}
else{
  echo '<script>alert("Something went wrong. please try again");window.location.assign("register.php");</script>';
}

?>