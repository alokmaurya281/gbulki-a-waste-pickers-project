
<?php
include('check_login.php');
include('db.php');
$userid = $_SESSION['userid'];
?><?php 
    $location = mysqli_real_escape_string($con,$_POST['location']);
    $sql = "UPDATE customer SET location='$location' WHERE email='$userid' ";
    
if(mysqli_query($con, $sql)){

  echo '<script>alert("Selected ");window.location.assign("request.php");</script>';
  
}
else{
  echo '<script>alert("Please select Your location");window.location.assign("welcome.php");</script>';
}

?>