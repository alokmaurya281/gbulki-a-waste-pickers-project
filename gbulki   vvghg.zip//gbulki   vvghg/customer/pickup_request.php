   <?php
require('db.php');
include('check_login.php');
$userid = $_SESSION['userid'];
	

$name = mysqli_real_escape_string($con,$_POST['name']);
$email = mysqli_real_escape_string($con,$_POST['email']);
$phone = mysqli_real_escape_string($con,$_POST['phone']);
$address = mysqli_real_escape_string($con,$_POST['address']);
$sql = "INSERT INTO pickup_request(name, email, phone, address) VALUES('$name','$email','$phone','$address')";

		
if(mysqli_query($con, $sql)){

  echo '<script>alert("Request Send successfully.");window.location.assign("welcome.php");</script>';
  
}
else{
  echo '<script>alert("Something went wrong. please try again");window.location.assign("Request.php");</script>';
}

?>