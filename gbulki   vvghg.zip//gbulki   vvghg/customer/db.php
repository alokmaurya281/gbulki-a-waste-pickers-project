<?php
define('DB_SERVER','sql311.epizy.com');
define('DB_USER','epiz_28214208');
define('DB_PASS' ,'lgr2NmxObkEN');
define('DB_NAME', 'epiz_28214208_gbulki');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);

// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }

?>

