<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>GBulki || Create an account || Customer </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center">
        <img src="../assets/img/logo.png" alt="">
        <span>GBulki</span>
      </a>

      

    </div>
  </header><!-- End Header -->

  <main id="main">

  </main><!-- End #main -->

  <br>
  <br>
 <section>
   <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-12 text-center">
            <header class="section-header"> 
              <p>Create an Account - Customer</p>
            </header>
          </div>
          
          <div class="col-lg-6">
          
                        <form method="post" action="registration.php">
                            
                              <div class="row gy-4">
                                <div class="col-md-12">
                                      <input class="form-control" placeholder="Name" name="name" type="text" autofocus>
                                </div>
                                <div class="col-md-12">
                                      <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                                </div>
                                
                                  <div class="col-md-12">
                                    
                                        <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                    
                                </div>
                                <div class="col-md-12">
                                      <input class="form-control" placeholder="Phone" name="phone" type="text" autofocus>
                                </div>
                                <div class="col-md-12">
                <input type="checkbox" name="agree-term" required />
                <label >I agree all statements in  <a href="/terms" >Terms of service</a></label>
              </div>
                                  <div class="col-md-12 text-center">
                                      <!-- Change this to a button or input when using this as a form -->
                                      <button type="submit"  class="btn btn-success">Sign Up</button>
                                  </div>
                            </div></form>
                            <br><br>
                        <div class="row gy-4">
            <div class="col-md-12 text-center">
              <p>   Already Have an account?   <a href="index.php"> <button class="btn btn-primary">Login Here</button></a></p>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
</section>
    

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/purecounter/purecounter.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>

</body>
</html>