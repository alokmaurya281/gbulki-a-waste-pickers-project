<?php
include('check_login.php');
include('db.php');
$userid = $_SESSION['userid'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>GBulki || Customer Dashboard </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">
  <!--popup css-->
  <link rel="stylesheet" type="text/css" href="popup.css">


  
</head>

<body>

     <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span>GBulki</span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="scrap_price.php">Scrap Price</a></li>
          <li class="dropdown"><a href="#"><span>Your Location</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <?php
            $query = mysqli_query($con,"select * from customer where email='$userid'");
            $result = mysqli_fetch_array($query);
            $location = $result['location']; 
          ?>
              <li><a href="#"><?php echo $result['location']; ?></a></li>
            </ul>
          </li>
          
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
  

  <main id="main">

  </main><!-- End #main -->

  <br>
  <br>
 
					<!-- Location popup form-->
          <div class="popup" id="popup-1">
  <div class="overlay"></div>
  <div class="content" style=" width: 800px; height: 600px;">
    <div class="close-btn" onclick="togglePopup()">&times;</div>
    
    <header class="section-header">Raise a Pickup Request</header>
    
<?php
            $query = mysqli_query($con,"select * from customer where email='$userid'");
            $result = mysqli_fetch_array($query);
          ?>
     <form method="post" action="pickup_request.php">
                            
                              <div class="row gy-4">

                                <div class="col-md-12">
                                      <input class="form-control" placeholder="<?php echo $result['name'];?>" value="<?php echo $result['name'];?>" name="name" type="text" autofocus>
                                </div>
                                  <div class="col-md-12">
                                    
                                        <input class="form-control" placeholder="<?php echo $result['phone'];?>" name="phone" type="text" value="<?php echo $result['phone'];?>">
                                    
                                </div>
                                <div class="col-md-12">
                                    
                                        <input class="form-control" placeholder="<?php echo $result['email'];?>" name="email" type="text" value="<?php echo $result['email'];?>">
                                    
                                </div>
                                <div class="col-md-12">
                                    
                                        <input class="form-control" placeholder="<?php echo $result['location'];?>" name="location" type="text" value="<?php echo $result['location'];?>">
                                    
                                </div>
                                <div class="col-md-12">
                                    
                                        <input class="form-control" placeholder="<?php echo $result['address'];?>" name="address" type="text" value="<?php echo $result['address'];?>">
                                    
                                </div>
                                
                                  <div class="col-md-12">
                                      <!-- Change this to a button or input when using this as a form -->
                                      <button type="submit"  class="btn btn-success">Confirm Request</button>
                                  </div>
                            </div></form>
    
  </div>
</div>

<button class="btn btn-primary"onclick="togglePopup()">Raise a Pickup Request</button>	


  <!-- Vendor JS Files -->
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/purecounter/purecounter.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <!-- popup  js-->
  <script src="popup.js"></script>

</body>
</html>