-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql311.epizy.com
-- Generation Time: May 31, 2021 at 02:40 AM
-- Server version: 5.6.48-88.0
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_28214208_gbulki`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` text NOT NULL,
  `location` text NOT NULL,
  `address` text NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `email`, `password`, `name`, `phone`, `location`, `address`, `date_time`) VALUES
(1, 'snmaurya10275@gmail.com', 'alokm@12345', 'Alok Maurya', '0', '', '', '2021-04-02 06:04:54'),
(2, 'alok@gmail.com', 'alokm@12345', 'Alok', '7071994439', '', '', '2021-04-02 08:08:27'),
(3, 'priyanshu8572@gmail.com', '12345678', 'Priyanshu Singh', '7071994439', '', '', '2021-04-02 09:38:54'),
(4, 'gbulkipvtltd@gmail.com', 'gbulki@12345', 'Alok Maurya', '07071994439', '', '', '2021-04-02 09:46:31');

-- --------------------------------------------------------

--
-- Table structure for table `pickup_request`
--

CREATE TABLE `pickup_request` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` text NOT NULL,
  `location` text NOT NULL,
  `address` text NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pickup_request`
--

INSERT INTO `pickup_request` (`id`, `name`, `email`, `phone`, `location`, `address`, `date_time`) VALUES
(1, 'Alok Maurya', 'snmaurya10275@gmail.com', '07071994439', '', 'Vidhayak Road Jayram Nagar Fatehpur', '2021-04-06 13:38:27'),
(2, 'Surendra nath', 'a@n.com', '99999999888', '', 'Vidhayak Road Jayram Nagar Fatehpur', '2021-04-08 15:59:37');

-- --------------------------------------------------------

--
-- Table structure for table `waste_picker`
--

CREATE TABLE `waste_picker` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` text NOT NULL,
  `phone` text NOT NULL,
  `location` text NOT NULL,
  `address` text NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `waste_picker`
--

INSERT INTO `waste_picker` (`id`, `email`, `password`, `name`, `phone`, `location`, `address`, `date_time`) VALUES
(1, 'snmaurya10275@gmail.com', 'alokm@12345', 'Alok Maurya', '7071994439', '', '', '2021-04-02 08:40:54'),
(2, 'priyanshu8572@gmail.com', '12345678', 'Priyanshu Singh', '7071994439', '', '', '2021-04-02 09:37:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pickup_request`
--
ALTER TABLE `pickup_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `waste_picker`
--
ALTER TABLE `waste_picker`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pickup_request`
--
ALTER TABLE `pickup_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `waste_picker`
--
ALTER TABLE `waste_picker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
